# ParkFlow - Sistema de Estacionamiento

Sistema web de gestión de estacionamiento desarrollado con Laravel, MySQL, jQuery/AJAX y Bootstrap.

## Características principales

- Login de autenticación
- Gestión de clientes / abonados
- Registro de vehículos
- Control de espacios de estacionamiento
- Entradas y salidas (boletos) con cálculo de tarifa
- Reportes exportables a PDF y Excel (DataTables)
- Interfaz moderna y responsive

## Requisitos

- PHP 8.1+
- Composer
- MySQL / MariaDB
- Node.js (opcional para assets)

## Instalación

```bash
composer install
cp .env.example .env
php artisan key:generate
# Configura la base de datos en .env
php artisan migrate --seed
php artisan serve
```

## Módulos

1. **Espacios** - Visualización y estado de celdas
2. **Clientes** - Registro y gestión de clientes
3. **Vehículos** - Placas, marcas y asociación a clientes
4. **Boletos** - Entrada / salida y control operativo

---
ParkFlow © 2025
