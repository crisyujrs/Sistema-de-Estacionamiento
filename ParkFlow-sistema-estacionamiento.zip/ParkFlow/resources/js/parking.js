$(document).ready(function() {
    console.log("ParkFlow - Sistema de Estacionamiento listo.");

    // Interceptar cualquier envío de formulario de guardado o salida
    $('form').on('submit', function(e) {
        let btn = $(this).find('button[type="submit"]');
        let textoBtn = btn.text().toLowerCase();

        // Verificamos si es un botón de acción principal (Guardar o Registrar)
        if (textoBtn.includes('guardar') || textoBtn.includes('entrada') || textoBtn.includes('salida') || btn.hasClass('btn-warning')) {
            e.preventDefault(); // Frenamos el envío inmediato
            let form = this;

            let tituloAccion = '¡Registro Exitoso!';
            let mensajeAccion = 'Los datos se han guardado correctamente en el sistema.';
            let iconoTipo = 'success';

            if (textoBtn.includes('salida') || btn.hasClass('btn-warning')) {
                tituloAccion = '¿Confirmar salida?';
                mensajeAccion = 'Se calculará el tiempo y la tarifa correspondiente.';
                iconoTipo = 'warning';
            } else if (textoBtn.includes('guardar')) {
                tituloAccion = '¡Guardado con éxito!';
                mensajeAccion = 'El nuevo registro ya figura en la base de datos.';
            }

            Swal.fire({
                title: tituloAccion,
                text: mensajeAccion,
                icon: iconoTipo,
                confirmButtonColor: '#0284c7',
                confirmButtonText: 'Aceptar',
                showCancelButton: iconoTipo === 'warning',
                cancelButtonColor: '#d33',
                cancelButtonText: 'Cancelar'
            }).then((result) => {
                if (result.isConfirmed) {
                    form.submit(); // Envía el formulario y se queda en la misma vista con estilo profesional
                }
            });
        }
    });
});