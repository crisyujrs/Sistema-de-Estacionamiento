<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Espacios - ParkFlow</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { font-family: 'Poppins', sans-serif; background-color: #f0f9ff; }
        .sidebar { position: fixed; top: 0; bottom: 0; left: 0; width: 250px; background: linear-gradient(180deg, #0c4a6e 0%, #075985 100%); color: #fff; padding-top: 1.5rem; z-index: 100; box-shadow: 4px 0 18px rgba(0,0,0,0.12); }
        .sidebar .brand { font-weight: 700; padding: 0 1.5rem; margin-bottom: 2.2rem; font-size: 1.35rem; letter-spacing: 0.5px; }
        .sidebar .nav-link { color: #bae6fd; padding: 0.8rem 1.5rem; font-weight: 500; border-radius: 0 25px 25px 0; margin-right: 12px; transition: all 0.2s ease; }
        .sidebar .nav-link:hover, .sidebar .nav-link.active { color: #fff; background-color: rgba(255,255,255,0.18); border-left: 4px solid #38bdf8; }
        .sidebar .nav-link i { margin-right: 12px; width: 20px; text-align: center; }
        .main-content { margin-left: 250px; padding: 2rem; }
        .navbar-top { background: #fff; border-bottom: 1px solid #e0f2fe; padding: 0.9rem 2rem; margin-left: 250px; position: sticky; top: 0; z-index: 99; box-shadow: 0 1px 4px rgba(0,0,0,0.04); }
        .card-custom { border: none; background: #fff; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); }
        .btn-accent { background-color: #0284c7; border-color: #0284c7; color: #fff; }
        .btn-accent:hover { background-color: #0369a1; border-color: #0369a1; color: #fff; }
    </style>
</head>
<body>
    <div class="sidebar d-flex flex-column justify-content-between">
        <div>
            <div class="brand text-white"><i class="fa-solid fa-car-side me-2"></i>ParkFlow</div>
            <ul class="nav flex-column">
                <li class="nav-item"><a href="{{ route('espacios.index') }}" class="nav-link active"><i class="fa-solid fa-th-large"></i> Espacios</a></li>
                <li class="nav-item"><a href="{{ route('clientes.index') }}" class="nav-link"><i class="fa-solid fa-user-friends"></i> Clientes</a></li>
                <li class="nav-item"><a href="{{ route('vehiculos.index') }}" class="nav-link"><i class="fa-solid fa-car"></i> Vehículos</a></li>
                <li class="nav-item"><a href="{{ route('boletos.index') }}" class="nav-link"><i class="fa-solid fa-ticket-alt"></i> Boletos</a></li>
            </ul>
        </div>
        <div class="p-3">
            <form action="{{ route('logout') }}" method="POST">
                @csrf
                <button type="submit" class="btn btn-outline-light w-100 btn-sm rounded-pill"><i class="fa-solid fa-sign-out-alt me-2"></i> Cerrar Sesión</button>
            </form>
        </div>
    </div>

    <div class="navbar-top d-flex justify-content-between align-items-center">
        <span class="fw-semibold text-secondary"><i class="fa-solid fa-th-large me-2 text-primary"></i>Módulo de Espacios</span>
    </div>

    <div class="main-content">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="fw-bold mb-1">Espacios de Estacionamiento - ParkFlow</h2>
        </div>

        <div class="card card-custom p-4">
            <table class="table table-hover align-middle">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Número / Identificador</th>
                        <th>Tipo</th>
                        <th>Estado</th>
                        <th class="text-end">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($espacios as $espacio)
                        <tr>
                            <td>{{ $espacio->id }}</td>
                            <td class="fw-bold">{{ $espacio->numero ?? $espacio->nombre ?? 'N/D' }}</td>
                            <td>{{ $espacio->tipo ?? 'General' }}</td>
                            <td>
                                <span class="badge {{ ($espacio->activo ?? 1) ? 'bg-success' : 'bg-secondary' }}">
                                    {{ ($espacio->activo ?? 1) ? 'Activo' : 'Inactivo' }}
                                </span>
                            </td>
                            <td class="text-end">
                                <form action="{{ route('espacios.toggle', $espacio->id) }}" method="POST" class="d-inline">
                                    @csrf
                                    @method('PATCH')
                                    <button type="submit" class="btn btn-sm {{ ($espacio->activo ?? 1) ? 'btn-outline-danger' : 'btn-outline-success' }}">
                                        {{ ($espacio->activo ?? 1) ? 'Desactivar' : 'Activar' }}
                                    </button>
                                </form>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="5" class="text-center text-muted py-4">No hay espacios registrados.</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>