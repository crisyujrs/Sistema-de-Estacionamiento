<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clientes - ParkFlow</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.1/css/buttons.bootstrap5.min.css">
    <style>
        body { font-family: 'Poppins', sans-serif; background-color: #f0f9ff; }
        .sidebar { position: fixed; top: 0; bottom: 0; left: 0; width: 250px; background: linear-gradient(180deg, #0c4a6e 0%, #075985 100%); color: #fff; padding-top: 1.5rem; z-index: 100; box-shadow: 4px 0 18px rgba(0,0,0,0.12); }
        .sidebar .brand { font-weight: 700; padding: 0 1.5rem; margin-bottom: 2.2rem; font-size: 1.35rem; letter-spacing: 0.5px; }
        .sidebar .nav-link { color: #bae6fd; padding: 0.8rem 1.5rem; font-weight: 500; border-radius: 0 25px 25px 0; margin-right: 12px; transition: all 0.2s ease; }
        .sidebar .nav-link:hover, .sidebar .nav-link.active { color: #fff; background-color: rgba(255,255,255,0.18); border-left: 4px solid #38bdf8; }
        .sidebar .nav-link i { margin-right: 12px; width: 20px; text-align: center; }
        .main-content { margin-left: 250px; padding: 2rem; }
        .navbar-top { background: #fff; border-bottom: 1px solid #e0f2fe; padding: 0.9rem 2rem; margin-left: 250px; position: sticky; top: 0; z-index: 99; box-shadow: 0 1px 4px rgba(0,0,0,0.04); }
        .card-custom { border: none; background: #fff; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); }
        .btn-accent { background-color: #0284c7; border-color: #0284c7; color: #fff; }
        .btn-accent:hover { background-color: #0369a1; border-color: #0369a1; color: #fff; }
    </style>
</head>
<body>
    <div class="sidebar d-flex flex-column justify-content-between">
        <div>
            <div class="brand text-white"><i class="fa-solid fa-car-side me-2"></i>ParkFlow</div>
            <ul class="nav flex-column">
                <li class="nav-item"><a href="{{ route('espacios.index') }}" class="nav-link"><i class="fa-solid fa-th-large"></i> Espacios</a></li>
                <li class="nav-item"><a href="{{ route('clientes.index') }}" class="nav-link active"><i class="fa-solid fa-user-friends"></i> Clientes</a></li>
                <li class="nav-item"><a href="{{ route('vehiculos.index') }}" class="nav-link"><i class="fa-solid fa-car"></i> Vehículos</a></li>
                <li class="nav-item"><a href="{{ route('boletos.index') }}" class="nav-link"><i class="fa-solid fa-ticket-alt"></i> Boletos</a></li>
            </ul>
        </div>
        <div class="p-3">
            <form action="{{ route('logout') }}" method="POST">
                @csrf
                <button type="submit" class="btn btn-outline-light w-100 btn-sm rounded-pill"><i class="fa-solid fa-sign-out-alt me-2"></i> Cerrar Sesión</button>
            </form>
        </div>
    </div>
    <div class="navbar-top d-flex justify-content-between align-items-center">
        <span class="fw-semibold text-secondary"><i class="fa-solid fa-users me-2 text-primary"></i>Gestión de Clientes</span>
    </div>
    <div class="main-content">
        <h2 class="fw-bold mb-4">Gestión de Clientes</h2>
        @if(session('success'))
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            Swal.fire({
                title: '¡Éxito!',
                text: "{{ session('success') }}",
                icon: 'success',
                confirmButtonColor: '#0284c7',
                confirmButtonText: 'Aceptar'
            });
        });
    </script>
@endif


        <div class="card card-custom p-4 mb-4">
            <h5 class="fw-bold mb-3 text-primary">Registrar Nuevo Cliente</h5>
            <form action="{{ route('clientes.store') }}" method="POST" class="row g-3">
                @csrf
                <div class="col-md-4">
                    <label class="form-label">Nombre</label>
                    <input type="text" name="nombre" class="form-control" required placeholder="Nombre completo">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Teléfono</label>
                    <input type="text" name="telefono" class="form-control" placeholder="Número de contacto">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Correo</label>
                    <input type="email" name="correo" class="form-control" placeholder="correo@example.com">
                </div>
                <div class="col-12 text-end">
                    <button type="submit" class="btn btn-accent px-4 rounded-pill">Guardar Cliente</button>
                </div>
            </form>
        </div>
        <div class="card card-custom p-4">
            <table id="tablaClientes" class="table table-hover align-middle w-100">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Teléfono</th>
                        <th>Correo</th>
                        <th>Estado</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($clientes as $cliente)
                        <tr>
                            <td>{{ $cliente->id }}</td>
                            <td class="fw-bold">{{ $cliente->nombre }}</td>
                            <td>{{ $cliente->telefono ?? 'S/N' }}</td>
                            <td>{{ $cliente->correo ?? 'S/N' }}</td>
                            <td>
                                @if($cliente->activo)
                                    <span class="badge bg-success">Activo</span>
                                @else
                                    <span class="badge bg-danger">Inactivo</span>
                                @endif
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.4.1/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.bootstrap5.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.html5.min.js"></script>
    <script src="{{ asset('js/parking.js') }}"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        $(document).ready(function() {
            $('#tablaClientes').DataTable({
                language: {
                    "processing": "Procesando...",
                    "lengthMenu": "Mostrar _MENU_ registros",
                    "zeroRecords": "No se encontraron resultados",
                    "emptyTable": "Ningún dato disponible en esta tabla",
                    "info": "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
                    "infoEmpty": "Mostrando registros del 0 al 0 de un total de 0 registros",
                    "infoFiltered": "(filtrado de un total de _MAX_ registros)",
                    "search": "Buscar:",
                    "loadingRecords": "Cargando...",
                    "paginate": {
                        "first": "Primero",
                        "last": "Último",
                        "next": "Siguiente",
                        "previous": "Anterior"
                    }
                },
                pageLength: 10,
                lengthMenu: [5, 10, 25, 50],
                order: [[0, 'desc']],
                dom: '<"d-flex justify-content-between align-items-center mb-3"Bf>rt<"d-flex justify-content-between align-items-center mt-3"lip>',
                buttons: [
                    {
                        extend: 'excelHtml5',
                        text: '<i class="fa-solid fa-file-excel me-1"></i> Exportar Excel',
                        className: 'btn btn-success btn-sm',
                        title: 'Reporte de Clientes - ParkFlow'
                    },
                    {
                        extend: 'pdfHtml5',
                        text: '<i class="fa-solid fa-file-pdf me-1"></i> Exportar PDF',
                        className: 'btn btn-danger btn-sm ms-2',
                        title: 'Reporte de Clientes - ParkFlow'
                    }
                ]
            });
        });
    </script>
</body>
</html>