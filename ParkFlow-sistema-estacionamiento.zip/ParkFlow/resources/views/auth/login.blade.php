<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión - ParkFlow</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #0c4a6e 0%, #0369a1 50%, #0284c7 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .login-card {
            width: 100%;
            max-width: 420px;
            border: none;
            border-radius: 16px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.2);
            overflow: hidden;
        }
        .login-header {
            background: linear-gradient(135deg, #0c4a6e, #075985);
            color: white;
            padding: 2rem 1.5rem;
            text-align: center;
        }
        .login-header i {
            font-size: 2.5rem;
            margin-bottom: 0.5rem;
        }
        .login-body {
            padding: 2rem 1.75rem;
            background: #fff;
        }
        .form-control:focus {
            border-color: #0284c7;
            box-shadow: 0 0 0 0.2rem rgba(2, 132, 199, 0.25);
        }
        .btn-login {
            background: linear-gradient(135deg, #0284c7, #0369a1);
            border: none;
            padding: 0.75rem;
            font-weight: 600;
            letter-spacing: 0.3px;
        }
        .btn-login:hover {
            background: linear-gradient(135deg, #0369a1, #0c4a6e);
        }
    </style>
</head>
<body>
    <div class="card login-card">
        <div class="login-header">
            <i class="fa-solid fa-car-side"></i>
            <h3 class="mb-0 fw-bold">ParkFlow</h3>
            <p class="mb-0 small opacity-75">Sistema de Estacionamiento</p>
        </div>
        <div class="login-body">
            @if($errors->any())
                <div class="alert alert-danger py-2">
                    {{ $errors->first() }}
                </div>
            @endif

            <form action="{{ route('login.submit') }}" method="POST">
                @csrf
                <div class="mb-3">
                    <label class="form-label fw-medium">Correo Electrónico</label>
                    <div class="input-group">
                        <span class="input-group-text bg-light border-end-0"><i class="fa-solid fa-envelope text-muted"></i></span>
                        <input type="email" name="correo_electronico" class="form-control border-start-0" required placeholder="usuario@ejemplo.com">
                    </div>
                </div>
                <div class="mb-4">
                    <label class="form-label fw-medium">Contraseña</label>
                    <div class="input-group">
                        <span class="input-group-text bg-light border-end-0"><i class="fa-solid fa-lock text-muted"></i></span>
                        <input type="password" name="contrasena" class="form-control border-start-0" required placeholder="••••••••">
                    </div>
                </div>
                <button type="submit" class="btn btn-primary btn-login w-100 rounded-pill">
                    <i class="fa-solid fa-right-to-bracket me-2"></i>Ingresar
                </button>
            </form>
        </div>
    </div>
</body>
</html>
