<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\ClienteController;
use App\Http\Controllers\VehiculoController;
use App\Http\Controllers\EspacioController;
use App\Http\Controllers\BoletoController;

// Redirigir la raíz directamente al módulo de boletos (o login si prefieres)
Route::get('/', function () {
    return redirect()->route('espacios.index');
});

// Rutas de autenticación
Route::post('/login', [AuthController::class, 'login'])->name('login.submit');
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

// Rutas de alternar estado (Activo/Inactivo)
Route::patch('/clientes/{id}/toggle', [ClienteController::class, 'toggleStatus'])->name('clientes.toggle');
Route::patch('/vehiculos/{id}/toggle', [VehiculoController::class, 'toggleStatus'])->name('vehiculos.toggle');
Route::patch('/espacios/{id}/toggle', [EspacioController::class, 'toggleStatus'])->name('espacios.toggle');

// Ruta para registrar salida y cobro de boleto
Route::patch('/boletos/{id}/salida', [BoletoController::class, 'registrarSalida'])->name('boletos.salida');

// Módulos protegidos con recursos (CRUDs)
Route::resource('clientes', ClienteController::class);
Route::resource('vehiculos', VehiculoController::class);
Route::resource('espacios', EspacioController::class);
Route::resource('boletos', BoletoController::class);