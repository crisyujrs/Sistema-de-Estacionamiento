<?php

namespace App\Http\Controllers;

use App\Models\Boleto;
use App\Models\Vehiculo;
use App\Models\Espacio;
use Illuminate\Http\Request;
use Carbon\Carbon;

class BoletoController extends Controller
{
    public function index()
    {
        $boletos = Boleto::with(['vehiculo', 'espacio'])->orderBy('id', 'desc')->get();
        $vehiculos = Vehiculo::where('activo', 1)->get();$espacios = Espacio::where('activo', 1)->get();

        return view('boletos.index', compact('boletos', 'vehiculos', 'espacios'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'vehiculo_id' => 'required|exists:vehiculos,id',
            'espacio_id' => 'required|exists:espacios,id',
        ]);

        // Validar si el espacio ya está ocupado por un boleto activo (sin hora de salida)
        $espacioOcupado = Boleto::where('espacio_id',$request->espacio_id)
            ->whereNull('hora_salida')
            ->exists();

        if ($espacioOcupado) {
            return back()->with('error', 'Este espacio ya está ocupado por otro vehículo. Seleccione otro.');
        }

        // Validar si el vehículo ya está adentro del estacionamiento
        $vehiculoAdentro = Boleto::where('vehiculo_id',$request->vehiculo_id)
            ->whereNull('hora_salida')
            ->exists();

        if ($vehiculoAdentro) {
            return back()->with('error', 'Este vehículo ya se encuentra estacionado adentro.');
        }

        Boleto::create([
            'vehiculo_id' => $request->vehiculo_id,
            'espacio_id' => $request->espacio_id,
            'hora_entrada' => Carbon::now('America/La_Paz'),
            'total' => 0,
        ]);

        return back()->with('success', 'Entrada registrada correctamente.');
    }

    // Alias para que funcione sin importar cómo esté escrito en routes/web.php
    public function registrarSalida($id)
    {
        return $this->salida($id);
    }

    public function salida($id)
    {
        $boleto = Boleto::findOrFail($id);

        if ($boleto->hora_salida) {
            return back()->with('error', 'Este boleto ya fue cobrado y cerrado.');
        }

        $horaSalida = Carbon::now('America/La_Paz');
        $horaEntrada = Carbon::parse($boleto->hora_entrada, 'America/La_Paz');

        $minutos = $horaEntrada->diffInMinutes($horaSalida);
        if ($minutos < 1) {$minutos = 1; // Cobro mínimo de 1 minuto
        }

        // Tarifa: 5 Bs por hora
        $total = ($minutos / 60) * 5;

        $boleto->update([
            'hora_salida' => $horaSalida,
            'total' => round($total, 2),
        ]);

        return back()->with('success', 'Salida y cobro registrados. Total a pagar: ' . number_format($total, 2) . ' Bs');
    }
}