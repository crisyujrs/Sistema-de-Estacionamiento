<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Vehiculo;
use App\Models\Cliente;

class VehiculoController extends Controller
{
    public function index()
    {
        $vehiculos = Vehiculo::orderBy('id', 'desc')->get();
        // Agregamos esto para que la vista reciba los clientes activos:
        $clientes = Cliente::where('activo', 1)->get();

        return view('vehiculos.index', compact('vehiculos', 'clientes'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'placa' => 'required|unique:vehiculos,placa',
            'cliente_id' => 'required',
        ]);

        $vehiculo = new Vehiculo();
        $vehiculo->placa = $request->placa;
        $vehiculo->marca = $request->marca;
        $vehiculo->cliente_id = $request->cliente_id;
        $vehiculo->activo = 1; // Por defecto activo
        $vehiculo->save();

        return redirect()->route('vehiculos.index')->with('success', 'Vehículo registrado con éxito.');
    }

    public function toggleStatus($id)
    {
        $vehiculo = Vehiculo::findOrFail($id);
        $vehiculo->activo = !$vehiculo->activo;
        $vehiculo->save();

        return redirect()->route('vehiculos.index')->with('success', 'Estado del vehículo actualizado.');
    }
}