<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\EspacioEstacionamiento; // Asegúrate de que este sea el nombre de tu modelo

class EspacioController extends Controller
{
    public function index()
    {
        $espacios = EspacioEstacionamiento::all();
        return view('espacios.index', compact('espacios'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'numero' => 'required',
            'tipo' => 'required'
        ]);

        EspacioEstacionamiento::create($request->all());
        return redirect()->route('espacios.index')->with('success', 'Espacio registrado con éxito.');
    }

    public function toggleStatus($id)
    {
        $espacio = EspacioEstacionamiento::findOrFail($id);
        $espacio->activo = ($espacio->activo == 1) ? 0 : 1;
        $espacio->save();

        return redirect()->route('espacios.index');
    }
}