<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Usuario;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;

class AuthController extends Controller
{
    public function showLoginForm()
    {
        return view('auth.login');
    }

    public function login(Request $request)
    {
        $request->validate([
            'correo_electronico' => 'required|email',
            'contrasena' => 'required'
        ]);

        $usuario = Usuario::where('correo_electronico', $request->correo_electronico)->first();

        if ($usuario && ($request->contrasena === $usuario->contrasena || Hash::check($request->contrasena, $usuario->contrasena))) {
            Session::put('usuario_id', $usuario->id);
            Session::put('usuario_nombre', $usuario->nombre);
            return redirect()->route('espacios.index');
        }

        return back()->withErrors(['correo_electronico' => 'Las credenciales son incorrectas.']);
    }

    public function logout()
    {
        Session::flush();
        return redirect()->route('login');
    }
}