<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Boleto extends Model
{
    use HasFactory;

    protected $table = 'boletos';

    protected $fillable = [
        'vehiculo_id',
        'espacio_id',
        'hora_entrada',
        'hora_salida',
        'total',
    ];

    // Relación con Vehículo
    public function vehiculo()
    {
        return $this->belongsTo(Vehiculo::class, 'vehiculo_id');
    }

    // Relación con Espacio
    public function espacio()
    {
        return $this->belongsTo(Espacio::class, 'espacio_id');
    }
}