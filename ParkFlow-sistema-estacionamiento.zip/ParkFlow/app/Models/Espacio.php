<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Espacio extends Model
{
    use HasFactory;

    protected $table = 'espacios';

    protected $fillable = [
        'numero',
        'identificador',
        'tipo',
        'activo',
    ];

    public function boletos()
    {
        return $this->hasMany(Boleto::class, 'espacio_id');
    }
}