<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Vehiculo extends Model
{
    use HasFactory;

    protected $table = 'vehiculos';

    protected $fillable = ['placa', 'marca', 'cliente_id', 'activo'];

    // Esta función es la que vincula el vehículo con su cliente:
    public function cliente()
    {
        return $this->belongsTo(Cliente::class, 'cliente_id');
    }
}