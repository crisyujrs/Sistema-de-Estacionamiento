<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class EspacioEstacionamiento extends Model
{
    protected $table = 'espacios_estacionamiento';
    public $timestamps = false;
}